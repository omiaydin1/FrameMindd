import { createPublicClient, http, type Address, formatEther } from 'viem';
import { base } from 'viem/chains';

const RECIPIENT_ADDRESS = '0x71AAD1110dFd8F60249cD45ce4fb05163b6f812B' as Address;
const REQUIRED_AMOUNT = 0.0001; // ETH
const VALIDITY_PERIOD = 30 * 24 * 60 * 60 * 1000; // 30 days in milliseconds

export interface PaymentStatus {
  isPremium: boolean;
  lastPaymentDate: number | null;
  lastPaymentAmount: string | null;
  daysRemaining: number;
  transactionHash?: string;
}

/**
 * Verify payment onchain using Base network
 * Enhanced with comprehensive error handling and validation
 */
export async function verifyPaymentOnchain(
  userAddress: Address,
  transactionHash?: string
): Promise<{ 
  verified: boolean; 
  amount?: string; 
  timestamp?: number;
  error?: string;
}> {
  try {
    // Create Base network client with multiple RPC endpoints for reliability
    const client = createPublicClient({
      chain: base,
      transport: http('https://mainnet.base.org', {
        timeout: 30000, // 30 second timeout
        retryCount: 3,
        retryDelay: 1000,
      }),
    });

    if (!transactionHash) {
      return { 
        verified: false,
        error: 'No transaction hash provided'
      };
    }

    try {
      // Step 1: Get transaction receipt to verify it exists on Base
      const receipt = await client.getTransactionReceipt({
        hash: transactionHash as `0x${string}`,
      });

      if (!receipt) {
        console.error('Transaction receipt not found on Base network');
        return { 
          verified: false,
          error: 'Transaction not found on Base network. Make sure you paid on Base, not Ethereum mainnet.'
        };
      }

      // Step 2: Verify transaction succeeded
      if (receipt.status !== 'success') {
        console.error('Transaction failed on Base network');
        return { 
          verified: false,
          error: 'Transaction failed on Base network. Please try again.'
        };
      }

      // Step 3: Get full transaction details
      const tx = await client.getTransaction({
        hash: transactionHash as `0x${string}`,
      });

      if (!tx) {
        return { 
          verified: false,
          error: 'Unable to retrieve transaction details from Base network'
        };
      }

      // Step 4: Verify recipient address
      if (tx.to?.toLowerCase() !== RECIPIENT_ADDRESS.toLowerCase()) {
        console.error(`Wrong recipient. Expected: ${RECIPIENT_ADDRESS}, Got: ${tx.to}`);
        return { 
          verified: false,
          error: `Payment sent to wrong address. Expected ${RECIPIENT_ADDRESS}` 
        };
      }

      // Step 5: Verify sender address
      if (tx.from.toLowerCase() !== userAddress.toLowerCase()) {
        console.error(`Wrong sender. Expected: ${userAddress}, Got: ${tx.from}`);
        return { 
          verified: false,
          error: 'Transaction sender does not match your wallet address'
        };
      }

      // Step 6: Verify payment amount
      const amount = formatEther(tx.value);
      const amountFloat = parseFloat(amount);
      
      console.log(`Payment verification: Amount = ${amount} ETH (${amountFloat}), Required = ${REQUIRED_AMOUNT} ETH`);
      
      if (amountFloat < REQUIRED_AMOUNT) {
        console.error(`Insufficient payment. Required: ${REQUIRED_AMOUNT} ETH, Got: ${amount} ETH`);
        return { 
          verified: false,
          error: `Payment amount too low. Required: ${REQUIRED_AMOUNT} ETH, Received: ${amount} ETH`
        };
      }

      // Step 7: Get block timestamp
      const block = await client.getBlock({ blockHash: receipt.blockHash });
      const timestamp = Number(block.timestamp) * 1000;

      console.log(`✓ Payment verified on Base network`);
      console.log(`  - Amount: ${amount} ETH`);
      console.log(`  - From: ${userAddress}`);
      console.log(`  - To: ${RECIPIENT_ADDRESS}`);
      console.log(`  - Tx Hash: ${transactionHash}`);
      console.log(`  - Timestamp: ${new Date(timestamp).toISOString()}`);
      
      return {
        verified: true,
        amount,
        timestamp,
      };
      
    } catch (txError: any) {
      // Handle transaction not found on Base specifically
      if (txError.message?.includes('not found') || txError.message?.includes('does not exist')) {
        console.error('Transaction not found on Base network:', txError);
        return { 
          verified: false,
          error: 'Transaction not found on Base network. Did you send payment on Ethereum mainnet instead? Please use Base network.'
        };
      }
      throw txError;
    }
  } catch (error: any) {
    console.error('Error verifying payment onchain:', error);
    
    // Provide specific error messages
    if (error.message?.includes('timeout')) {
      return { 
        verified: false,
        error: 'Base network connection timeout. Please try again in a moment.'
      };
    }
    
    if (error.message?.includes('network')) {
      return { 
        verified: false,
        error: 'Unable to connect to Base network. Please check your internet connection.'
      };
    }
    
    return { 
      verified: false,
      error: 'Payment verification failed. Please contact support if this persists.'
    };
  }
}

/**
 * Check if user has paid 0.0001 ETH or more in the last 30 days
 * Now properly verifies on Base network
 */
export async function checkPremiumStatus(userAddress: Address): Promise<PaymentStatus> {
  try {
    const thirtyDaysAgo = Date.now() - VALIDITY_PERIOD;
    
    // Check localStorage for cached premium status
    const cachedStatus = localStorage.getItem(`premium_${userAddress}`);
    if (cachedStatus) {
      try {
        const parsed: PaymentStatus = JSON.parse(cachedStatus);
        if (parsed.lastPaymentDate && parsed.lastPaymentDate > thirtyDaysAgo) {
          const daysRemaining = Math.ceil((parsed.lastPaymentDate + VALIDITY_PERIOD - Date.now()) / (24 * 60 * 60 * 1000));
          
          // If we have a transaction hash, verify it's still valid on Base
          if (parsed.transactionHash) {
            const verification = await verifyPaymentOnchain(userAddress, parsed.transactionHash);
            if (verification.verified) {
              return {
                ...parsed,
                daysRemaining,
              };
            }
          } else {
            // Trust cached status if within validity period
            return {
              ...parsed,
              daysRemaining,
            };
          }
        }
      } catch (e) {
        console.error('Error parsing cached status:', e);
      }
    }

    // If no valid cache, return free tier
    return {
      isPremium: false,
      lastPaymentDate: null,
      lastPaymentAmount: null,
      daysRemaining: 0,
    };

  } catch (error) {
    console.error('Error checking premium status:', error);
    return {
      isPremium: false,
      lastPaymentDate: null,
      lastPaymentAmount: null,
      daysRemaining: 0,
    };
  }
}

/**
 * Record a payment in localStorage after successful Base transaction
 * Enhanced with detailed verification and error messages
 */
export async function recordPayment(
  userAddress: Address,
  amount: string,
  transactionHash: string
): Promise<{ success: boolean; error?: string }> {
  try {
    console.log(`Verifying payment on Base network: ${transactionHash}`);
    
    // Verify the transaction is actually on Base network
    const verification = await verifyPaymentOnchain(userAddress, transactionHash);
    
    if (!verification.verified) {
      const errorMsg = verification.error || 'Payment verification failed - transaction not found on Base network';
      console.error('Payment verification failed:', errorMsg);
      return {
        success: false,
        error: errorMsg
      };
    }

    // Record premium status
    const status: PaymentStatus = {
      isPremium: true,
      lastPaymentDate: verification.timestamp || Date.now(),
      lastPaymentAmount: verification.amount || amount,
      daysRemaining: 30,
      transactionHash,
    };
    
    localStorage.setItem(`premium_${userAddress}`, JSON.stringify(status));
    console.log('✓ Premium status activated successfully');
    console.log('Payment details saved:', {
      address: userAddress,
      amount: status.lastPaymentAmount,
      date: new Date(status.lastPaymentDate).toISOString(),
      txHash: transactionHash.slice(0, 10) + '...',
    });
    
    return { success: true };
  } catch (error: any) {
    const errorMsg = error.message || 'Error recording payment';
    console.error('Error recording payment:', errorMsg);
    return {
      success: false,
      error: errorMsg
    };
  }
}

/**
 * Prepare payment transaction data for Base network
 */
export function preparePaymentTransaction(fromAddress: Address) {
  return {
    to: RECIPIENT_ADDRESS,
    value: BigInt(Math.floor(REQUIRED_AMOUNT * 1e18)), // Convert to wei
    from: fromAddress,
    chainId: base.id, // Explicitly set Base chain ID
    data: '0x' as `0x${string}`,
  };
}

/**
 * Format ETH amount for display
 */
export function formatPaymentAmount(wei: bigint): string {
  return formatEther(wei);
}

/**
 * Get Base network explorer URL for transaction
 */
export function getTransactionUrl(hash: string): string {
  return `https://basescan.org/tx/${hash}`;
}
