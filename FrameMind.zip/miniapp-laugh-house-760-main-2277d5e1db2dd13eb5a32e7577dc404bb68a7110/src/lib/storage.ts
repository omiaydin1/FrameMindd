export interface CachedInsight {
  summary: string;
  trending: string[];
  suggestions: string[];
  timestamp: number;
  fid: number;
}

const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Save AI insights to localStorage
 */
export function saveCachedInsights(fid: number, insights: Omit<CachedInsight, 'timestamp' | 'fid'>): void {
  const cached: CachedInsight = {
    ...insights,
    timestamp: Date.now(),
    fid,
  };
  
  try {
    localStorage.setItem(`insights_${fid}`, JSON.stringify(cached));
  } catch (error) {
    console.error('Error saving cached insights:', error);
  }
}

/**
 * Get cached AI insights from localStorage
 */
export function getCachedInsights(fid: number): CachedInsight | null {
  try {
    const cached = localStorage.getItem(`insights_${fid}`);
    if (!cached) return null;
    
    const parsed: CachedInsight = JSON.parse(cached);
    const age = Date.now() - parsed.timestamp;
    
    // Return null if cache is older than 24 hours
    if (age > CACHE_DURATION) {
      localStorage.removeItem(`insights_${fid}`);
      return null;
    }
    
    return parsed;
  } catch (error) {
    console.error('Error getting cached insights:', error);
    return null;
  }
}

/**
 * Clear cached insights for a user
 */
export function clearCachedInsights(fid: number): void {
  try {
    localStorage.removeItem(`insights_${fid}`);
  } catch (error) {
    console.error('Error clearing cached insights:', error);
  }
}

/**
 * Clear all cached data older than 30 days
 */
export function cleanupOldCache(): void {
  try {
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('insights_')) {
        const cached = localStorage.getItem(key);
        if (cached) {
          const parsed = JSON.parse(cached);
          if (parsed.timestamp < thirtyDaysAgo) {
            localStorage.removeItem(key);
          }
        }
      }
    }
  } catch (error) {
    console.error('Error cleaning up old cache:', error);
  }
}
