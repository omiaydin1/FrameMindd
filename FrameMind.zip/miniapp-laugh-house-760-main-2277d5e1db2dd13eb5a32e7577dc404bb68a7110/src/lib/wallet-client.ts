/**
 * ===============================================================================
 * Wallet Client Integration - Secure Transaction Handler for Base Network
 * ===============================================================================
 * 
 * This module provides wallet transaction functionality using viem and wagmi.
 * Specifically designed for Base network donations with proper error handling.
 */

import { createWalletClient, custom, parseEther, type Address, type Hash } from 'viem';
import { base } from 'viem/chains';

export interface TransactionRequest {
  to: Address;
  value: string; // ETH amount as string (e.g., "0.0001")
  data?: `0x${string}`;
}

export interface TransactionResult {
  success: boolean;
  hash?: Hash;
  error?: string;
}

export interface TransactionReceipt {
  hash: Hash;
  status: 'success' | 'reverted';
  blockNumber: bigint;
  confirmations: number;
}

/**
 * Check if wallet is available (MetaMask, Coinbase Wallet, etc.)
 */
export function isWalletAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  return !!(window as any).ethereum;
}

/**
 * Get the current connected wallet address
 */
export async function getConnectedAddress(): Promise<Address | null> {
  try {
    if (!isWalletAvailable()) {
      console.error('[Wallet] No wallet provider found');
      return null;
    }

    const ethereum = (window as any).ethereum;
    
    // Request accounts
    const accounts = await ethereum.request({ 
      method: 'eth_requestAccounts' 
    }) as Address[];
    
    if (!accounts || accounts.length === 0) {
      console.error('[Wallet] No accounts connected');
      return null;
    }

    console.log('[Wallet] Connected address:', accounts[0]);
    return accounts[0];
    
  } catch (error) {
    console.error('[Wallet] Error getting connected address:', error);
    return null;
  }
}

/**
 * Switch to Base network if not already on it
 */
export async function switchToBaseNetwork(): Promise<boolean> {
  try {
    if (!isWalletAvailable()) {
      throw new Error('No wallet provider found');
    }

    const ethereum = (window as any).ethereum;
    
    // Try to switch to Base
    try {
      await ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${base.id.toString(16)}` }], // Base chain ID: 8453 (0x2105)
      });
      
      console.log('[Wallet] ✓ Switched to Base network');
      return true;
      
    } catch (switchError: any) {
      // Chain not added, try to add it
      if (switchError.code === 4902 || switchError.code === -32603) {
        console.log('[Wallet] Base network not found, adding it...');
        
        await ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: `0x${base.id.toString(16)}`,
            chainName: base.name,
            nativeCurrency: base.nativeCurrency,
            rpcUrls: ['https://mainnet.base.org'],
            blockExplorerUrls: ['https://basescan.org'],
          }],
        });
        
        console.log('[Wallet] ✓ Added and switched to Base network');
        return true;
      }
      
      throw switchError;
    }
    
  } catch (error) {
    console.error('[Wallet] Error switching to Base network:', error);
    return false;
  }
}

/**
 * Send a transaction on Base network
 */
export async function sendTransaction(request: TransactionRequest): Promise<TransactionResult> {
  const startTime = Date.now();
  
  console.log('\n=== Wallet Transaction Started ===');
  console.log('To:', request.to);
  console.log('Value:', request.value, 'ETH');
  console.log('Network: Base');
  console.log('Timestamp:', new Date().toISOString());
  
  try {
    // Check wallet availability
    if (!isWalletAvailable()) {
      throw new Error('No wallet provider found. Please install MetaMask or Coinbase Wallet.');
    }

    // Get connected address
    const fromAddress = await getConnectedAddress();
    if (!fromAddress) {
      throw new Error('Please connect your wallet first');
    }

    console.log('From:', fromAddress);

    // Switch to Base network
    const switched = await switchToBaseNetwork();
    if (!switched) {
      throw new Error('Please switch to Base network in your wallet');
    }

    // Create wallet client with viem
    const walletClient = createWalletClient({
      chain: base,
      transport: custom((window as any).ethereum),
    });

    console.log('[Transaction] Wallet client created, sending transaction...');

    // Send transaction
    const hash = await walletClient.sendTransaction({
      account: fromAddress,
      to: request.to,
      value: parseEther(request.value),
      data: request.data || '0x',
      chain: base,
    });

    const latency = Date.now() - startTime;
    console.log(`[Transaction] ✓ Transaction sent in ${latency}ms`);
    console.log('[Transaction] Hash:', hash);
    console.log('=== Transaction Complete ===\n');

    return {
      success: true,
      hash,
    };
    
  } catch (error: any) {
    const latency = Date.now() - startTime;
    console.error(`[Transaction] ✗ Error after ${latency}ms:`, error);
    console.log('=== Transaction Failed ===\n');
    
    // User-friendly error messages
    let errorMessage = 'Transaction failed';
    
    if (error.message) {
      if (error.message.includes('User rejected') || error.message.includes('User denied')) {
        errorMessage = 'Transaction cancelled by user';
      } else if (error.message.includes('insufficient funds')) {
        errorMessage = 'Insufficient funds for transaction';
      } else if (error.message.includes('network')) {
        errorMessage = 'Network error. Please check your connection';
      } else {
        errorMessage = error.message;
      }
    }
    
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Wait for transaction confirmation on Base
 */
export async function waitForTransaction(hash: Hash): Promise<TransactionReceipt | null> {
  try {
    console.log('[Transaction] Waiting for confirmation...', hash);
    
    if (!isWalletAvailable()) {
      console.error('[Transaction] No wallet provider');
      return null;
    }

    const ethereum = (window as any).ethereum;
    
    // Poll for transaction receipt
    let attempts = 0;
    const maxAttempts = 60; // 60 seconds max
    
    while (attempts < maxAttempts) {
      try {
        const receipt = await ethereum.request({
          method: 'eth_getTransactionReceipt',
          params: [hash],
        });
        
        if (receipt) {
          const status = receipt.status === '0x1' ? 'success' : 'reverted';
          
          console.log('[Transaction] ✓ Confirmed!');
          console.log('[Transaction] Status:', status);
          console.log('[Transaction] Block:', receipt.blockNumber);
          
          return {
            hash,
            status,
            blockNumber: BigInt(receipt.blockNumber),
            confirmations: 1,
          };
        }
      } catch (err) {
        // Receipt not ready yet, continue polling
      }
      
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
    }
    
    console.warn('[Transaction] ⏱ Confirmation timeout after 60s');
    return null;
    
  } catch (error) {
    console.error('[Transaction] Error waiting for confirmation:', error);
    return null;
  }
}

/**
 * Get Base block explorer URL for transaction
 */
export function getBlockExplorerUrl(hash: Hash): string {
  return `https://basescan.org/tx/${hash}`;
}
